# LanShare 部署说明

## 快速开始

### 系统要求
- Docker 20.10+
- Docker Compose 2.0+
- 至少 1GB 可用内存
- 至少 2GB 可用磁盘空间

### 启动方式

#### Linux/macOS
```bash
chmod +x start.sh
./start.sh
```

#### Windows
```cmd
start.bat
```

#### 手动启动
```bash
# 构建并启动
docker-compose up -d --build

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

## 访问地址

- **本地访问**: http://127.0.0.1:7070
- **网络访问**: http://[你的IP地址]:7070

## 功能特性

### ✅ 已修复的问题
- 中文文件名正确显示
- 图片/视频/音频预览功能正常
- 聊天文件与传输文件独立管理
- 密码保护功能正常
- 版本检查和更新功能

### 主要功能
1. **文件传输**: 支持各种文件类型的上传和下载
2. **实时聊天**: 支持文本和文件消息
3. **文件预览**: 支持图片、视频、音频在线预览
4. **密码保护**: 可选的访问密码保护
5. **版本管理**: 自动检查更新

## 配置说明

### 环境变量
可以通过修改 `docker-compose.yml` 中的环境变量来配置：

```yaml
environment:
  - GITHUB_REPO=Danborad/lanshare  # GitHub 仓库
  - DOCKER_REPO=zhong12138/lanshare  # Docker Hub 仓库
  - VERSION_CHECK_MODE=auto  # 版本检查模式
```

### 数据持久化
- 上传文件: `./uploads/`
- 数据库文件: `./data/`
- 配置文件: `./data/settings.json`

## 故障排除

### 常见问题

1. **端口被占用**
   ```bash
   # 修改 docker-compose.yml 中的端口映射
   ports:
     - "8080:7070"  # 改为其他端口
   ```

2. **权限问题**
   ```bash
   # Linux/macOS 设置权限
   chmod -R 755 uploads/
   chmod -R 755 data/
   ```

3. **内存不足**
   ```bash
   # 增加 Docker 内存限制
   # 在 docker-compose.yml 中添加：
   deploy:
     resources:
       limits:
         memory: 1G
   ```

### 查看日志
```bash
# 查看所有日志
docker-compose logs

# 实时查看日志
docker-compose logs -f

# 查看特定服务日志
docker-compose logs lanshare
```

## 更新说明

### 版本信息
- 当前版本: LanShare v1.2.0
- 构建时间: 2025-09-22
- 平台: Docker

### 更新方法
1. 停止服务: `docker-compose down`
2. 拉取最新镜像: `docker-compose pull`
3. 重新启动: `docker-compose up -d`

## 技术支持

如果遇到问题，请检查：
1. Docker 和 Docker Compose 是否正确安装
2. 端口 7070 是否被占用
3. 防火墙设置是否允许访问
4. 查看容器日志获取详细错误信息

## 许可证

本项目采用 MIT 许可证。
