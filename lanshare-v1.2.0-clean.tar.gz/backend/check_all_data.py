import sqlite3
import os

# 连接到数据库
db_path = 'data/lanshare.db'
print(f"数据库路径: {os.path.abspath(db_path)}")

if not os.path.exists(db_path):
    print("数据库文件不存在!")
else:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 查询所有表名
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cursor.fetchall()
    print('数据库中的表:')
    for table in tables:
        print(f"  {table[0]}")

    # 查询files表中的所有记录
    cursor.execute("SELECT id, filename, file_path, file_type FROM files")
    rows = cursor.fetchall()
    
    print('\n文件记录:')
    if not rows:
        print("  无记录")
    else:
        for row in rows:
            print(f"  ID: {row[0]}, 文件名: {row[1]}, 路径: {row[2]}, 类型: {row[3]}")

    # 查询messages表中的所有记录
    cursor.execute("SELECT * FROM messages")
    rows = cursor.fetchall()
    
    # 获取列名
    column_names = [description[0] for description in cursor.description]
    print(f'\n消息表列名: {column_names}')
    
    print('\n消息记录:')
    if not rows:
        print("  无记录")
    else:
        for row in rows:
            print(f"  {row}")

    # 关闭连接
    conn.close()