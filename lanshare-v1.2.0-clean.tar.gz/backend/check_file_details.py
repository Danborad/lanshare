import sqlite3
import os

# 连接到数据库
db_path = 'data/lanshare.db'
print(f"数据库路径: {os.path.abspath(db_path)}")

if not os.path.exists(db_path):
    print("数据库文件不存在!")
else:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 查询ID为1的文件记录
    cursor.execute("SELECT * FROM files WHERE id=1")
    row = cursor.fetchone()
    
    if row:
        print('\nID为1的文件记录:')
        # 获取列名
        column_names = [description[0] for description in cursor.description]
        for i, (column, value) in enumerate(zip(column_names, row)):
            print(f"  {column}: {value}")
            
        # 检查文件是否存在
        file_path = row[column_names.index('file_path')]
        print(f"\n文件路径: {file_path}")
        print(f"文件是否存在: {os.path.exists(file_path)}")
        if os.path.exists(file_path):
            print(f"文件大小: {os.path.getsize(file_path)} 字节")
    else:
        print("未找到ID为1的文件记录")
        
    # 查询ID为6的文件记录
    cursor.execute("SELECT * FROM files WHERE id=6")
    row = cursor.fetchone()
    
    if row:
        print('\nID为6的文件记录:')
        # 获取列名
        column_names = [description[0] for description in cursor.description]
        for i, (column, value) in enumerate(zip(column_names, row)):
            print(f"  {column}: {value}")
            
        # 检查文件是否存在
        file_path = row[column_names.index('file_path')]
        print(f"\n文件路径: {file_path}")
        print(f"文件是否存在: {os.path.exists(file_path)}")
        if os.path.exists(file_path):
            print(f"文件大小: {os.path.getsize(file_path)} 字节")
    else:
        print("未找到ID为6的文件记录")

    # 关闭连接
    conn.close()