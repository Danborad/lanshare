import os
import hashlib

# 检查uploads目录
upload_dir = 'uploads'
print(f"当前目录: {os.getcwd()}")
print(f"uploads目录是否存在: {os.path.exists(upload_dir)}")

if os.path.exists(upload_dir):
    files = os.listdir(upload_dir)
    print(f"uploads目录中的文件数量: {len(files)}")
    for file in files:
        file_path = os.path.join(upload_dir, file)
        file_size = os.path.getsize(file_path)
        print(f"  文件: {file} (大小: {file_size} 字节)")
        
        # 计算文件的MD5哈希值
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        file_hash = hash_md5.hexdigest()
        print(f"    MD5: {file_hash}")
else:
    print("uploads目录不存在")
    
# 检查data目录
data_dir = 'data'
print(f"\ndata目录是否存在: {os.path.exists(data_dir)}")

if os.path.exists(data_dir):
    files = os.listdir(data_dir)
    print(f"data目录中的文件: {files}")
    
    # 检查数据库文件
    db_file = os.path.join(data_dir, 'lanshare.db')
    if os.path.exists(db_file):
        db_size = os.path.getsize(db_file)
        print(f"数据库文件大小: {db_size} 字节")
    else:
        print("数据库文件不存在")
else:
    print("data目录不存在")