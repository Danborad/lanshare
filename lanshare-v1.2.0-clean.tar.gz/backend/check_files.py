import sqlite3

# 连接到数据库
conn = sqlite3.connect('data/lanshare.db')
cursor = conn.cursor()

# 查询所有文件记录，包含更多字段
cursor.execute("SELECT id, filename, file_path, file_type FROM files")
rows = cursor.fetchall()

print('文件记录:')
for row in rows:
    print(f"ID: {row[0]}, 文件名: {row[1]}, 路径: {row[2]}, 类型: {row[3]}")

# 关闭连接
conn.close()