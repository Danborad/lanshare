import sqlite3
import os

# 连接到数据库
db_path = 'data/lanshare.db'
print(f"数据库路径: {os.path.abspath(db_path)}")

if not os.path.exists(db_path):
    print("数据库文件不存在!")
else:
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # 查询所有消息记录
    cursor.execute("SELECT * FROM messages")
    rows = cursor.fetchall()
    
    if not rows:
        print('\n消息表中没有记录')
    else:
        # 获取列名
        column_names = [description[0] for description in cursor.description]
        print(f'\n列名: {column_names}')
        
        print('\n所有消息记录:')
        for i, row in enumerate(rows):
            print(f"\n记录 {i+1}:")
            for column, value in zip(column_names, row):
                print(f"  {column}: {value}")

    # 关闭连接
    conn.close()