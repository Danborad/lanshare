import sqlite3

# 连接到数据库
conn = sqlite3.connect('data/lanshare.db')
cursor = conn.cursor()

# 查询所有表名
cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = cursor.fetchall()

print('数据库中的表:')
for table in tables:
    print(table)

# 关闭连接
conn.close()