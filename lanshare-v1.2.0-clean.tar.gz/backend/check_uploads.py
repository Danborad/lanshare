import os

uploads_dir = 'uploads'
if os.path.exists(uploads_dir):
    print('uploads目录内容:', os.listdir(uploads_dir))
else:
    print('uploads目录不存在')

# 检查当前目录
print('当前目录:', os.getcwd())
print('当前目录内容:', os.listdir('.'))