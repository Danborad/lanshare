const express = require('express')
const bcrypt = require('bcryptjs')
const fs = require('fs')
const path = require('path')
const router = express.Router()

const SETTINGS_FILE = path.join(__dirname, '..', 'data', 'settings.json')

// 确保数据目录存在
const dataDir = path.dirname(SETTINGS_FILE)
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true })
}

// 读取设置
const readSettings = () => {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      return JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'))
    }
  } catch (error) {
    console.error('读取设置失败:', error)
  }
  return {
    passwordEnabled: false,
    password: null,
    setupCompleted: false
  }
}

// 保存设置
const saveSettings = (settings) => {
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2))
    return true
  } catch (error) {
    console.error('保存设置失败:', error)
    return false
  }
}

// 检查是否需要首次设置
router.get('/setup-status', async (req, res) => {
  try {
    const settings = readSettings()
    res.json({
      needsSetup: !settings.setupCompleted
    })
  } catch (error) {
    console.error('检查设置状态失败:', error)
    res.json({ needsSetup: true })
  }
})

// 首次设置
router.post('/first-setup', async (req, res) => {
  try {
    const { usePassword, password } = req.body
    
    if (usePassword && (!password || password.length < 4)) {
      return res.status(400).json({ error: '密码长度至少为4位' })
    }

    const settings = readSettings()
    
    if (settings.setupCompleted) {
      return res.status(400).json({ error: '设置已完成' })
    }

    settings.setupCompleted = true
    settings.passwordEnabled = usePassword
    settings.channels = ['工作区', '生活区']  // 添加默认频道
    
    if (usePassword) {
      const hashedPassword = await bcrypt.hash(password, 10)
      settings.password = hashedPassword
    } else {
      settings.password = null
    }

    if (saveSettings(settings)) {
      res.json({ success: true })
    } else {
      res.status(500).json({ error: '保存设置失败' })
    }
  } catch (error) {
    console.error('首次设置失败:', error)
    res.status(500).json({ error: '设置失败' })
  }
})

// 获取当前设置
router.get('/', async (req, res) => {
  try {
    const settings = readSettings()
    res.json({
      passwordEnabled: settings.passwordEnabled,
      setupCompleted: settings.setupCompleted
    })
  } catch (error) {
    console.error('获取设置失败:', error)
    res.status(500).json({ error: '获取设置失败' })
  }
})

// 验证密码
router.post('/verify-password', async (req, res) => {
  try {
    const { password } = req.body
    const settings = readSettings()

    if (!settings.passwordEnabled) {
      return res.json({ valid: true })
    }

    if (!settings.password) {
      return res.json({ valid: true })
    }

    const isValid = await bcrypt.compare(password, settings.password)
    res.json({ valid: isValid })
  } catch (error) {
    console.error('验证密码失败:', error)
    res.status(500).json({ error: '验证失败' })
  }
})

// 更新密码设置
router.put('/password', async (req, res) => {
  try {
    const { passwordEnabled, password, currentPassword } = req.body
    const settings = readSettings()

    // 验证当前密码
    if (settings.passwordEnabled && settings.password) {
      if (!currentPassword) {
        return res.status(400).json({ error: '当前密码不能为空' })
      }

      const isValid = await bcrypt.compare(currentPassword, settings.password)
      if (!isValid) {
        return res.status(400).json({ error: '当前密码错误' })
      }
    }

    settings.passwordEnabled = passwordEnabled
    
    if (passwordEnabled && password) {
      if (password.length < 4) {
        return res.status(400).json({ error: '密码长度至少为4位' })
      }
      const hashedPassword = await bcrypt.hash(password, 10)
      settings.password = hashedPassword
    } else {
      settings.password = null
    }

    if (saveSettings(settings)) {
      res.json({ success: true })
    } else {
      res.status(500).json({ error: '保存设置失败' })
    }
  } catch (error) {
    console.error('更新密码设置失败:', error)
    res.status(500).json({ error: '更新失败' })
  }
})

module.exports = router