import sqlite3
import os

# 检查两个数据库文件
db_files = ['data/database.db', 'data/lanshare.db']

for db_path in db_files:
    print(f"\n检查数据库: {db_path}")
    if not os.path.exists(db_path):
        print("  数据库文件不存在!")
        continue
        
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # 检查所有表
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        print(f'  所有表: {[table[0] for table in tables]}')

        # 检查files表数据
        try:
            cursor.execute("SELECT COUNT(*) FROM files")
            count = cursor.fetchone()[0]
            print(f'  files表记录数: {count}')
        except Exception as e:
            print(f"  查询files表时出错: {e}")

        # 检查messages表数据
        try:
            cursor.execute("SELECT COUNT(*) FROM messages")
            count = cursor.fetchone()[0]
            print(f'  messages表记录数: {count}')
        except Exception as e:
            print(f"  查询messages表时出错: {e}")

        # 关闭连接
        conn.close()
    except Exception as e:
        print(f"  连接数据库时出错: {e}")